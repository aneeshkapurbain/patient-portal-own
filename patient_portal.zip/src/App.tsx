import * as React from 'react'
import Box from '@mui/material/Box'
import CssBaseline from '@mui/material/CssBaseline'
import { styled, ThemeProvider, createTheme } from '@mui/material/styles'
import Sidebar from './components/elements/Sidebar/Sidebar'
import Header from './components/elements/Header/Header'
import { Routes, Route, BrowserRouter } from 'react-router-dom'
import Support from './components/screens/Support/Support'
import MyDevice from './components/screens/MyDevice/MyDevice'
import Faq from './components/screens/Faq/Faq'
import MyAccount from './components/screens/MyAccount/MyAccount'

function App(): React.ReactElement {
  const [desktopOpen, setDesktopOpen] = React.useState(true)
  const [mobileOpen, setMobileOpen] = React.useState(false)
  const drawerWidth = 250

  const theme1 = createTheme({
    palette: {
      primary: {
        main: '#0F5CA2'
      }
    },
    typography: {
      button: {
        textTransform: 'none'
      }
    },
    components: {
      MuiListItemButton: {
        styleOverrides: {
          root: {
            '&.Mui-selected': {
              backgroundColor: '#313A46',
              color: '#ffffff'
            },
            '&.Mui-selected&:hover': {
              backgroundColor: '#313A46' // Change this to the desired hover background color
            }
          }
        }
      },
      MuiButton: {
        styleOverrides: {
          root: {
            borderWidth: '2px' // Set border width and color
          }
        }
      }
    }
  })

  const Main = styled('main', { shouldForwardProp: prop => prop !== 'open' })<{
    open?: boolean
  }>(({ theme, open }) => ({
    flexGrow: 1,
    padding: theme.spacing(3),
    transition: theme.transitions.create('margin', {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.leavingScreen
    }),
    marginLeft: `-${drawerWidth}px`,
    ...(desktopOpen && {
      transition: theme.transitions.create('margin', {
        easing: theme.transitions.easing.easeOut,
        duration: theme.transitions.duration.enteringScreen
      }),
      marginLeft: 0
    }),
    backgroundColor: '#F4F6F9',
    // height: '100vh',
    paddingTop: '5rem',
    display: 'flex', // Add this line
    alignItems: 'center', // Add this line
    justifyContent: 'center' // Add this line
  }))

  const CardsList = styled('div')(() => ({
    maxWidth: '774px'
  }))

  return (
    <ThemeProvider theme={theme1}>
      <Box sx={{ display: 'flex' }}>
        <BrowserRouter>
          <CssBaseline />
          <Sidebar
            desktopOpen={desktopOpen}
            mobileOpen={mobileOpen}
            setMobileOpen={setMobileOpen}></Sidebar>
          <Header
            desktopOpen={desktopOpen}
            setDesktopOpen={setDesktopOpen}
            mobileOpen={mobileOpen}
            setMobileOpen={setMobileOpen}></Header>
          <Main open={desktopOpen}>
            <CardsList>
              <Routes>
                <Route path="/" element={<MyDevice />}></Route>
                <Route path="/faq" element={<Faq />}></Route>
                <Route path="/support" element={<Support />}></Route>
                <Route path="/my-account" element={<MyAccount />}></Route>
              </Routes>
            </CardsList>
          </Main>
        </BrowserRouter>
      </Box>
    </ThemeProvider>
  )
}
export default App
