import { type ReactNode } from 'react'

export type CardIconMapping = Record<string, ReactNode>

interface CardConfig {
  type: 'card_config'
  content: string
  icon: 'NORMAL_FUNC' | 'NORMAL_TRANSM'
}

interface DevicePassport {
  type: 'device_passort'
  title: string
  device_detials: {
    device_img_src: string
    device_name: string
    status_title: string
    status: string
    transmission_schedule_title: string
    transmission_schedule: string
  }
  battery_details: {
    title: string
    due_date: string
    text: string
    note: string
  }
  additional_data: Array<{ title: string; data: string }>
}

export type MyDevicesConfig = Array<CardConfig | DevicePassport>
