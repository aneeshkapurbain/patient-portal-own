import NormalFunc from '../images/NormalFunc'
import NormalTransm from '../images/NormalTransm'

const useMyDevicesConfig = () => {
  const myDevicesConfig = [
    {
      type: 'card_config',
      content:
        'Your device is functioning normally and stands ready to support you in your daily activities.',
      icon: 'NORMAL_FUNC'
    },
    {
      type: 'card_config',
      content:
        'Your home monitor is transmitting and you are under regular monitoring by our care team.',
      icon: 'NORMAL_TRANSM'
    },
    {
      type: 'device_passort',
      title: 'MY DEVICE PASSPORT',
      device_detials: {
        device_img_src: '',
        device_name: '',
        status_title: '',
        status: '',
        transmission_schedule_title: '',
        transmission_schedule: ''
      },
      battery_details: {
        title: 'Battery replacement due in',
        due_date: '2025',
        text: 'Your clinic will notify you when your battery is due for replacement.',
        note: "Note: Battery life is indicative only, determined by the manufacturer's suggested lifespan, and may vary based on usage."
      },
      additional_data: [
        { title: 'Model Number', data: 'PM-2023-X' },
        { title: 'Lead model name', data: 'CardioLink UltraPro' },
        { title: 'Serial number', data: 'X284VFMF03KL2' },
        { title: 'Implant date', data: 'January 15, 2021' }
      ]
    }
  ]

  const cardIconMapping = {
    NORMAL_FUNC: <NormalFunc />,
    NORMAL_TRANSM: <NormalTransm />
  }

  return { myDevicesConfig, cardIconMapping }
}

export default useMyDevicesConfig
