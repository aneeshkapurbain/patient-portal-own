import { Box } from '@mui/material'
import Paper from '@mui/material/Paper'
import { styled } from '@mui/material/styles'
import useMyDevicesConfig from './hooks/useMyDevicesConfig'
import { type CardIconMapping, type MyDevicesConfig } from './types/types'

const Item = styled(Paper)(({ theme }) => ({
  ...theme.typography.body2,
  textAlign: 'center',
  color: theme.palette.text.secondary,
  padding: theme.spacing(1.5), // Default padding for all screen sizes

  [theme.breakpoints.down('sm')]: {
    padding: theme.spacing(0.875) // Override for sm and below
  },
  [theme.breakpoints.between('lg', 'sm')]: {
    padding: theme.spacing(1.875) // Override for lg to sm
  },
  [theme.breakpoints.up('lg')]: {
    padding: theme.spacing(1.5) // Override for lg and above
  }
}))

const MyDevice = () => {
  const {
    myDevicesConfig,
    cardIconMapping
  }: { myDevicesConfig: MyDeviceConfig; cardIconMapping: CardIconMapping } =
    useMyDevicesConfig()

  return (
    <Box display="flex" flexDirection="column" rowGap="1rem">
      {(myDevicesConfig?.length ?? 0) > 0 || false
        ? myDevicesConfig?.map(({ type, ...item }, index: number) => (
            <Item key={index + type} elevation={1}>
              {cardIconMapping[icon]}
            </Item>
          ))
        : null}
    </Box>
  )
}

export default MyDevice
