import { Box } from '@mui/material'

const HomePage = () => {
  return <Box component="article">{'HomePage'}</Box>
}

export default HomePage
