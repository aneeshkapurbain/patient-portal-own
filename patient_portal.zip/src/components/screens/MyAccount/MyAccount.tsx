import { Box } from '@mui/material'

const MyAccount = () => {
  return <Box component="article">{'My Account'}</Box>
}

export default MyAccount
