CREATE DATABASE local_patient WITH OWNER = 'test_user';
-- Create a new user
--CREATE USER test_user WITH ENCRYPTED PASSWORD 'psql123';

-- Grant privileges to the new user
GRANT ALL PRIVILEGES ON DATABASE local_patient TO test_user;

\c local_patient;

SET role test_user;

CREATE TABLE PATIENT (
id int PRIMARY KEY,
name varchar(100),
age int,
address varchar(200),
created_by varchar(50),
created_on timestamp not null default now(),
updated_by varchar(50),
updated_on timestamp not null default now()
);


INSERT INTO PATIENT(id, name, age, address, created_by, updated_by) values (1,'John', 23, 'New Delhi','SA', 'SA');
INSERT INTO PATIENT(id, name, age, address, created_by,updated_by) values (2,'Chris', 24, 'Noida', 'SA', 'SA');

COMMIT;