class PatientUrls:
    # crud APIs for jobs

    get_patient_details = "/patient/{id}"
    get_patients_list = "/patient/list"
