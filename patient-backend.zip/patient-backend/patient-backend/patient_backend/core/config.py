from dotenv import load_dotenv
load_dotenv()

import os

try:
    ENVIRONMENT = os.environ
    print("env********", ENVIRONMENT)
except Exception as e:
    raise e

try:
    PATIENT_DATABASE = type(
        "PATIENT_DATABASE",
        (object,),
        {
            "DB_USER": ENVIRONMENT["POSTGRES_USER"],
            "DB_PASS": ENVIRONMENT["POSTGRES_PASSWORD"],
            "DB_HOST": ENVIRONMENT["POSTGRES_HOST"],
            "DB_PORT": ENVIRONMENT["POSTGRES_PORT"],
            "DB_NAME": ENVIRONMENT["POSTGRES_DB_NAME"]
        },
    )
    print("Real time Env Variables coming from host machine")
    print(f"DB_USER : {ENVIRONMENT['POSTGRES_USER']}"),
    print(f"DB_PORT : {ENVIRONMENT['POSTGRES_HOST']}"),
    print(f"DB_PORT : {ENVIRONMENT['POSTGRES_PORT']}"),
    print(f"DB_USER : {ENVIRONMENT['POSTGRES_DB_NAME']}")
except Exception as e:
    print("Required Environment variables not found")
    print(str(e))
    raise e
