from sqlalchemy import Column, Integer, String

from patient_backend.db.common_models import BaseModel
from patient_backend.models import Base


class Patient(Base, BaseModel):
    __tablename__ = "patient"

    name = Column(String(100), index=True)
    age = Column(Integer, index=True)
    address = Column(String(200), nullable=True)
