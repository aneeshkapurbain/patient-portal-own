import patient_backend.models
from patient_backend import schemas, dao
from patient_backend.db.connection import DBConnection
from patient_backend.urls import PatientUrls
from patient_backend.utils.status_codes import HTTP_STATUS_CODE
from fastapi import Request, Depends, FastAPI, HTTPException
from sqlalchemy.orm import Session

conn = DBConnection()
get_db = conn.get_db


# Initialize sqlalchemy and Fast api aegi app
patient_backend.models.Base.metadata.create_all(bind=conn.engine)

app = FastAPI()


@app.get("/hello")
def read_root():
    return {"message": "Hello, World! We are live for testing"}


@app.get(PatientUrls.get_patients_list, status_code=HTTP_STATUS_CODE.OK, tags=["patients"])
def get_list_of_patients(request: Request, db: Session = Depends(get_db)):
    """
    API to retrieve a job status
    """
    list_of_patients = dao.list_patients(db)
    return schemas.ListPatients(
        patients=list_of_patients
    )
