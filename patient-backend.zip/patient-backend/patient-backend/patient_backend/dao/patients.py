from sqlalchemy.orm import Session
from patient_backend.models.main_models import Patient


def list_patients(db: Session):
    queryset = db.query(Patient)
    return queryset.order_by(Patient.created_on.desc()).all()


