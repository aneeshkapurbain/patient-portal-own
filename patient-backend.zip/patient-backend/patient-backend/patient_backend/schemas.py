from pydantic import BaseModel
from typing import Optional, List, Dict


class PatientDetail(BaseModel):
    """Patient Detail schema"""

    id: int
    name: str
    age: int
    address: str
    created_on: str
    created_by: Optional[str] = None


class ListPatients(BaseModel):
    patients: Optional[List[Dict]] = None



