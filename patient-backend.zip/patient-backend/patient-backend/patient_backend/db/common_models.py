from sqlalchemy import (
    String,
    Column,
    Integer,
    DateTime
)
from datetime import datetime


class BaseModel:
    """Base Model Containing Columns common to all models"""

    id = Column(Integer, primary_key=True, index=True)
    created_by = Column(String(50), nullable=True)
    created_on = Column(DateTime, default=datetime.utcnow())
    updated_by = Column(String(50), nullable=True)
    updated_on = Column(DateTime, default=None, onupdate=datetime.utcnow())
