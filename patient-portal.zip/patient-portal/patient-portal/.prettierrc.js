module.exports = {
    arrowParens: "avoid",
    bracketSameLine: true,
    bracketSpacing: false,
    singleQuote: false,
    trailingComma: "all",
    tabWidth: 2,
    useTabs: false,
    semi: true,
    printWidth: 80,
  };