import * as React from 'react'
import Box from '@mui/material/Box'
import CssBaseline from '@mui/material/CssBaseline'
import { styled, ThemeProvider, createTheme } from '@mui/material/styles'
import Sidebar from './components/elements/Sidebar/Sidebar'
import Header from './components/elements/Header/Header'
import { Routes, Route, BrowserRouter } from 'react-router-dom'
import Support from './components/screens/Support/Support'
import MyDevice from './components/screens/MyDevice/MyDevice'
import Faq from './components/screens/Faq/Faq'
import MyAccount from './components/screens/MyAccount/MyAccount'

const App = (): React.ReactElement => {
  const [desktopOpen, setDesktopOpen] = React.useState(true)
  const [mobileOpen, setMobileOpen] = React.useState(false)
  const drawerWidth = 250

  const theme1 = createTheme({
    palette: {
      primary: {
        main: '#0F5CA2'
      },
      background: {
        default: 'var(--background)' // Replace with your desired background color
      }
    },
    typography: {
      fontFamily: 'Arial',
      button: {
        textTransform: 'none'
      },
      h4: {
        fontSize: '1.875rem',
        '@media (max-width: 599.95px)': {
          fontSize: '1.625rem' // Override for sm and below
        },
        '@media (min-width: 600px) and (max-width: 959.95px)': {
          fontSize: '2.5rem' // Override for lg to sm
        },
        '@media (min-width: 960px)': {
          fontSize: '1.875rem' // Override for lg and above
        }
      },
      h5: {
        fontSize: '1.25rem',
        '@media (max-width: 599.95px)': {
          fontSize: '1rem' // Override for sm and below
        },
        '@media (min-width: 600px) and (max-width: 959.95px)': {
          fontSize: '1.625rem' // Override for lg to sm
        },
        '@media (min-width: 960px)': {
          fontSize: '1.25rem' // Override for lg and above
        }
      },
      h6: {
        fontSize: '1.25rem',
        '@media (max-width: 599.95px)': {
          fontSize: '1rem' // Override for sm and below
        },
        '@media (min-width: 600px) and (max-width: 959.95px)': {
          fontSize: '1.625rem' // Override for lg to sm
        },
        '@media (min-width: 960px)': {
          fontSize: '1.25rem' // Override for lg and above
        }
      },
      body1: {
        fontSize: '1.0625rem',
        '@media (max-width: 599.95px)': {
          fontSize: '0.75rem' // Override for sm and below
        },
        '@media (min-width: 600px) and (max-width: 959.95px)': {
          fontSize: '1.375rem' // Override for lg to sm
        },
        '@media (min-width: 960px)': {
          fontSize: '1.0625rem' // Override for lg and above
        }
      },
      subtitle2: {
        fontSize: '1.0625rem',
        '@media (max-width: 599.95px)': {
          fontSize: '0.75rem' // Override for sm and below
        },
        '@media (min-width: 600px) and (max-width: 959.95px)': {
          fontSize: '1.125rem' // Override for lg to sm
        },
        '@media (min-width: 960px)': {
          fontSize: '1.0625rem' // Override for lg and above
        }
      }
    },
    components: {
      MuiListItemButton: {
        styleOverrides: {
          root: {
            '&.Mui-selected': {
              backgroundColor: '#313A46',
              color: '#ffffff'
            },
            '&.Mui-selected&:hover': {
              backgroundColor: '#313A46' // Change this to the desired hover background color
            }
          }
        }
      },
      MuiButton: {
        styleOverrides: {
          root: {
            borderWidth: '2px' // Set border width and color
          }
        }
      }
    }
  })

  const Main = styled('main')(({ theme }) => ({
    flexGrow: 1,
    padding: theme.spacing(3),
    backgroundColor: '#F4F6F9',
    paddingTop: '5rem', // make responsive
    display: 'flex',
    justifyContent: 'center',
    '@media (min-width: 600px)': {
      transition: theme.transitions.create('margin', {
        easing: theme.transitions.easing.sharp,
        duration: theme.transitions.duration.leavingScreen
      }),
      marginLeft: `-${drawerWidth}px`,
      ...(desktopOpen && {
        transition: theme.transitions.create('margin', {
          easing: theme.transitions.easing.easeOut,
          duration: theme.transitions.duration.enteringScreen
        }),
        marginLeft: 0
      })
    }
  }))

  return (
    <ThemeProvider theme={theme1}>
      <Box sx={{ display: 'flex' }}>
        <BrowserRouter>
          <CssBaseline />
          <Sidebar
            desktopOpen={desktopOpen}
            mobileOpen={mobileOpen}
            setMobileOpen={setMobileOpen}></Sidebar>
          <Header
            desktopOpen={desktopOpen}
            setDesktopOpen={setDesktopOpen}
            mobileOpen={mobileOpen}
            setMobileOpen={setMobileOpen}></Header>
          <Main>
            <Box maxWidth={'39rem'}>
              <Routes>
                <Route path="/" element={<MyDevice />}></Route>
                <Route path="/faq" element={<Faq />}></Route>
                <Route path="/support" element={<Support />}></Route>
                <Route path="/my-account" element={<MyAccount />}></Route>
              </Routes>
            </Box>
          </Main>
        </BrowserRouter>
      </Box>
    </ThemeProvider>
  )
}
export default App
