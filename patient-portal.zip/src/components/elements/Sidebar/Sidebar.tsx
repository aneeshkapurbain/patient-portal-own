import Drawer from '@mui/material/Drawer'
import MyDevicesIcon from './images/MyDevicesIcon'
import FaqIcon from './images/FaqIcon'
import SupportIcon from './images/SupportIcon'
import MyAccountIcon from './images/MyAccountIcon'
import {
  Box,
  IconButton,
  List,
  ListItem,
  ListItemIcon,
  ListItemText,
  Toolbar
} from '@mui/material'
import MuiListItemButton from '@mui/material/ListItemButton' // type AppBarProps as MuiAppBarProps
import { styled } from '@mui/material/styles'
import {
  type Dispatch,
  type SetStateAction,
  useEffect,
  useState,
  useCallback
} from 'react'
import { useNavigate } from 'react-router-dom'
import React from 'react'
import CloseIcon from '@mui/icons-material/Close'

const Sidebar = ({
  desktopOpen,
  mobileOpen,
  setMobileOpen
}: {
  desktopOpen: boolean
  mobileOpen: boolean
  setMobileOpen: Dispatch<SetStateAction<boolean>>
}): React.ReactElement => {
  const [listItems, setListItems] = useState([
    {
      text: 'My device',
      selected: false,
      path: '',
      icon: <MyDevicesIcon selected={false} />
    },
    {
      text: 'FAQ',
      selected: false,
      path: 'faq',
      icon: <FaqIcon selected={false} />
    },
    {
      text: 'Support',
      selected: false,
      path: 'support',
      icon: <SupportIcon selected={false} />
    },
    {
      text: 'My account',
      selected: false,
      path: 'my-account',
      icon: <MyAccountIcon selected={false} />
    }
  ])

  const updateListItems = useCallback(
    (path: string): void => {
      const updatedListItems = listItems.map(item => {
        return {
          ...item,
          selected: path === item.path,
          icon:
            path === item.path
              ? React.cloneElement(item.icon, { selected: true })
              : React.cloneElement(item.icon, { selected: false })
        }
      })

      setListItems(updatedListItems)
    },
    [listItems]
  )

  useEffect(() => {
    const currentUrl = window.location.href
    const path = currentUrl.substring(currentUrl.lastIndexOf('/') + 1)
    updateListItems(path)
  }, [])

  const drawerWidth = 250
  const navigate = useNavigate()
  const handleDrawerClose = (): void => {
    setMobileOpen(false)
  }

  const ListItemButton = styled(MuiListItemButton)(({ selected = false }) => ({
    borderRadius: '12.153px',
    margin: '0 0.6rem'
  }))

  const drawer = (
    <div>
      <Toolbar>
        <IconButton
          sx={{
            display: { xs: 'block', sm: 'none' },
            marginLeft: 'auto',
            paddingLeft: '1rem'
          }}
          onClick={handleDrawerClose}>
          <CloseIcon />
        </IconButton>
      </Toolbar>
      <List>
        {listItems.map(({ text, selected, path, icon }, index) => (
          <ListItem
            key={text}
            disablePadding
            onClick={() => {
              updateListItems(path)
              navigate(`/${path}`)
            }}>
            <ListItemButton selected={selected}>
              <ListItemIcon>{icon}</ListItemIcon>
              <ListItemText primary={text} />
            </ListItemButton>
          </ListItem>
        ))}
      </List>
    </div>
  )

  return (
    <Box
      component="nav"
      sx={{ width: { sm: drawerWidth }, flexShrink: { sm: 0 } }}
      aria-label="mailbox folders">
      {/* The implementation can be swapped with js to avoid SEO duplication of links. */}
      <Drawer // mobile screens
        // container={container}
        variant="temporary"
        open={mobileOpen}
        // onTransitionEnd={handleDrawerTransitionEnd}
        onClose={handleDrawerClose}
        ModalProps={{
          keepMounted: true // Better open performance on mobile.
        }}
        sx={{
          display: { xs: 'block', sm: 'none' },
          '& .MuiDrawer-paper': {
            boxSizing: 'border-box',
            width: drawerWidth
          }
        }}>
        {drawer}
      </Drawer>
      <Drawer // large screens
        sx={{
          width: drawerWidth,
          flexShrink: 0,
          display: { xs: 'none', sm: 'block' },
          '& .MuiDrawer-paper': {
            width: drawerWidth,
            boxSizing: 'border-box'
          }
        }}
        variant="persistent"
        anchor="left"
        open={desktopOpen}>
        {/* <DrawerHeader>
          <IconButton onClick={handleDrawerClose}></IconButton>
        </DrawerHeader> */}
        {drawer}
      </Drawer>
    </Box>
  )
}

export default Sidebar
