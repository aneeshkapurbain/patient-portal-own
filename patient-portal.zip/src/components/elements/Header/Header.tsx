import MenuIcon from '@mui/icons-material/Menu'
import Toolbar from '@mui/material/Toolbar'
import { Button, IconButton, Stack } from '@mui/material'
import MuiAppBar, {
  type AppBarProps as MuiAppBarProps
} from '@mui/material/AppBar'
import { styled } from '@mui/material/styles'
import React, { type Dispatch, type SetStateAction } from 'react'

const Header = ({
  desktopOpen,
  setDesktopOpen,
  mobileOpen,
  setMobileOpen
}: {
  desktopOpen: boolean
  setDesktopOpen: Dispatch<SetStateAction<boolean>>
  mobileOpen: boolean
  setMobileOpen: Dispatch<SetStateAction<boolean>>
}): React.ReactElement => {
  const drawerWidth = 250
  const handleDrawerToggle = (): void => {
    setDesktopOpen(!desktopOpen)
    setMobileOpen(!mobileOpen)
  }

  interface AppBarProps extends MuiAppBarProps {
    open?: boolean
  }

  const AppBar = styled(MuiAppBar, {
    shouldForwardProp: prop => prop !== 'open'
  })<AppBarProps>(({ theme, open }) => ({
    transition: theme.transitions.create(['margin', 'width'], {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.leavingScreen
    }),
    ...(desktopOpen && {
      width: `calc(100% - ${drawerWidth}px)`,
      marginLeft: `${drawerWidth}px`,
      transition: theme.transitions.create(['margin', 'width'], {
        easing: theme.transitions.easing.easeOut,
        duration: theme.transitions.duration.enteringScreen
      })
    })
  }))

  return (
    <>
      <AppBar // desktop appbar
        position="fixed"
        sx={{
          display: { xs: 'none', sm: 'block' },
          backgroundColor: '#FFFFFF',
          boxShadow: '0px 1px 5px 0px rgba(46, 48, 48, 0.14)'
        }}
        open={desktopOpen}>
        <Toolbar>
          <IconButton
            color="inherit"
            aria-label="open drawer"
            edge="start"
            sx={{ mr: 2 }}>
            <Stack spacing={2} direction="row">
              <Button
                color="primary"
                variant="contained"
                aria-label="open drawer"
                onClick={handleDrawerToggle}
                startIcon={<MenuIcon />}>
                Menu
              </Button>
            </Stack>
          </IconButton>
        </Toolbar>
      </AppBar>
      <MuiAppBar // mobile app bar
        position="fixed"
        sx={{
          display: { xs: 'block', sm: 'none' },
          width: { sm: `calc(100% - ${drawerWidth}px)` },
          ml: { sm: `${drawerWidth}px` },
          backgroundColor: '#FFFFFF',
          boxShadow: '0px 1px 5px 0px rgba(46, 48, 48, 0.14)'
        }}>
        <Toolbar>
          <IconButton
            color="inherit"
            aria-label="open drawer"
            edge="start"
            sx={{ mr: 2 }}>
            <Stack spacing={2} direction="row">
              <Button
                color="primary"
                variant="contained"
                aria-label="open drawer"
                onClick={handleDrawerToggle}
                startIcon={<MenuIcon />}>
                Menu
              </Button>
            </Stack>
          </IconButton>
        </Toolbar>
      </MuiAppBar>
    </>
  )
}

export default Header
