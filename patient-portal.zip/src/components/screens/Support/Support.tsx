import { Box, Typography, ImageListItem, Button } from '@mui/material'

const Support = (): React.ReactElement => {
  const callingEnabled = 'telephony' in navigator

  const handleMailButtonClick = (): void => {
    // Replace the subject and body with your desired email content
    const subject = encodeURIComponent('Non-urgent message')
    const body = encodeURIComponent('Type your message here...')

    const mailtoLink = `mailto:test@clinic.com?subject=${subject}&body=${body}`

    // Open the default email client with the pre-filled email details
    window.location.href = mailtoLink
  }

  const handleCallClick = (): void => {
    const phoneNumber = '1800-123-456' // Replace with the actual phone number

    // Create a tel: link to open the default phone app
    const telLink = `tel:${phoneNumber}`

    // Open the default phone app with the specified phone number
    window.location.href = telLink
  }

  const renderCallingComponent = (): React.ReactElement => {
    if (callingEnabled) {
      return (
        <>
          {'Call '}
          <Button
            color="primary"
            variant="text"
            onClick={handleCallClick}
            fullWidth>
            1800-123-456
          </Button>
        </>
      )
    } else {
      return (
        <Button
          color="primary"
          variant="contained"
          onClick={handleCallClick}
          fullWidth>
          Call ClincABC support
        </Button>
      )
    }
  }

  return (
    <Box
      component="article"
      display="flex"
      flexDirection="column"
      alignItems="center"
      rowGap="1rem">
      <ImageListItem>
        <img
          src={'/images/support_banner.png'}
          alt={'support_img'}
          loading="lazy"
        />
      </ImageListItem>
      <Typography variant="body1" textAlign="center">
        Have any questions or concerns? contact us at&nbsp;
        <Typography
          component="span"
          variant="body1"
          textAlign="center"
          color="var(--primary)">
          1800-123-456
        </Typography>
        <br /> or send us a non-urgent message; our team will review within 48
        hours.
      </Typography>
      <Typography variant="body1" color="var(--gray)" textAlign="center">
        Note: This is not an Emergency Service.
        <br />
        If you are experiencing an emergency, please dial 000 immediately.
        <br />
        This platform is not intended for urgent situations. Use it for
        non-emergency
        <br />
        purposes and routine inquiries. Your safety is our priority.
      </Typography>
      {renderCallingComponent()}
      <Button
        color="primary"
        variant="outlined"
        onClick={handleMailButtonClick}
        fullWidth>
        Send a non-urgent message
      </Button>
    </Box>
  )
}

export default Support
