import { Box, Typography, ImageListItem, Button } from '@mui/material'
import styles from './styles.module.css'

const Support = () => {
  const callingEnabled = 'telephony' in navigator

  const handleMailButtonClick = () => {
    // Replace the subject and body with your desired email content
    const subject = encodeURIComponent('Non-urgent message')
    const body = encodeURIComponent('Type your message here...')

    const mailtoLink = `mailto:test@clinic.com?subject=${subject}&body=${body}`

    // Open the default email client with the pre-filled email details
    window.location.href = mailtoLink
  }

  const handleCallClick = () => {
    const phoneNumber = '1800-123-456' // Replace with the actual phone number

    // Create a tel: link to open the default phone app
    const telLink = `tel:${phoneNumber}`

    // Open the default phone app with the specified phone number
    window.location.href = telLink
  }

  return (
    <Box component="article" className={styles.articleContainer}>
      <ImageListItem>
        <img
          src={'/images/support_banner.png'}
          alt={'support_img'}
          loading="lazy"
        />
      </ImageListItem>
      <Typography className={styles.paragraph}>
        Have any questions or concerns? Contact us at{' '}
        <span className={styles.phoneNumber}>1800-123-456</span> or send us a
        non-urgent message; our team will review within 48 hours.
      </Typography>
      <Typography className={styles.note}>
        Note: This is not an Emergency Service. If you are experiencing an
        emergency, please dial 000 immediately. This platform is not intended
        for urgent situations. Use it for non-emergency purposes and routine
        inquiries. Your safety is our priority.
      </Typography>
      {callingEnabled ? (
        <>
          {'Call '}
          <Button
            color="primary"
            variant="text"
            onClick={handleCallClick}
            fullWidth>
            1800-123-456
          </Button>
        </>
      ) : (
        <Button
          color="primary"
          variant="contained"
          onClick={handleCallClick}
          fullWidth>
          Call ClincABC support
        </Button>
      )}
      <Button
        color="primary"
        variant="outlined"
        onClick={handleMailButtonClick}
        fullWidth>
        Send a non-urgent message
      </Button>
    </Box>
  )
}

export default Support
