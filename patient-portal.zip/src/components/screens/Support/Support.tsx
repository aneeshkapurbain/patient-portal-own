import { Box, Typography, ImageListItem, Button, Link } from '@mui/material'
// import { useEffect, useState } from 'react'

const Support = (): React.ReactElement => {
  // const [isMobile, setIsMobile] = useState(false)
  const isMobile = true
  // useEffect(() => {
  //   const mobileUserAgents = ['Android', 'iPhone']
  //   const userAgent = navigator.userAgent.toLowerCase()
  //   const isMobileDevice = mobileUserAgents.some(mobile =>
  //     userAgent.includes(mobile.toLowerCase())
  //   )

  //   // setIsMobile(isMobileDevice)
  // }, [])

  const handleMailButtonClick = (): void => {
    const subject = encodeURIComponent('Non-urgent message')
    const body = encodeURIComponent('Type your message here...')

    const mailtoLink = `mailto:test@clinic.com?subject=${subject}&body=${body}`

    window.location.href = mailtoLink
  }

  const handleCallClick = (): void => {
    const phoneNumber = '1800-123-456'
    const telLink = `tel:${phoneNumber}`

    window.location.href = telLink
  }

  const renderCallingComponent = (): React.ReactElement => {
    if (!isMobile) {
      return (
        <>
          <Box>
            <Typography variant="h4" display="inline" component="span">
              {'Call '}
            </Typography>
            <Typography
              variant="h4"
              display="inline"
              component="span"
              color="primary">
              <Link color="inherit" onClick={handleCallClick}>
                1800-123-456
              </Link>
            </Typography>
          </Box>
        </>
      )
    } else {
      return (
        <Button
          color="primary"
          variant="contained"
          onClick={handleCallClick}
          fullWidth>
          Call ClincABC support
        </Button>
      )
    }
  }

  return (
    <Box
      component="article"
      display="flex"
      flexDirection="column"
      alignItems="center"
      rowGap="1rem">
      <ImageListItem>
        <img
          src={'/images/support_banner.png'}
          alt={'support_img'}
          loading="lazy"
        />
      </ImageListItem>
      <Typography variant="body1" textAlign="center">
        Have any questions or concerns? contact us at&nbsp;
        <Typography
          component="span"
          variant="body1"
          textAlign="center"
          color="var(--primary)">
          1800-123-456
        </Typography>
        <br /> or send us a non-urgent message; our team will review within 48
        hours.
      </Typography>
      <Typography
        variant="body1"
        color="var(--gray)"
        textAlign="center"
        paddingBottom="1.75rem">
        Note: This is not an Emergency Service.
        <br />
        If you are experiencing an emergency, please dial 000 immediately.
        <br />
        This platform is not intended for urgent situations. Use it for
        non-emergency
        <br />
        purposes and routine inquiries. Your safety is our priority.
      </Typography>
      {renderCallingComponent()}
      {!isMobile && <Typography variant="subtitle2">{'or'}</Typography>}
      <Button
        color="primary"
        variant="outlined"
        onClick={handleMailButtonClick}
        fullWidth>
        Send a non-urgent message
      </Button>
    </Box>
  )
}

export default Support
