import { Box } from '@mui/material'

const HomePage = (): React.ReactElement => {
  return <Box component="article">{'HomePage'}</Box>
}

export default HomePage
