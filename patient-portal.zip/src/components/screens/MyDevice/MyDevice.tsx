import {
  Box,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableRow,
  Typography
} from '@mui/material'
import Paper from '@mui/material/Paper'
import { styled } from '@mui/material/styles'
import useMyDevicesConfig from './hooks/useMyDevicesConfig'
import {
  type CardConfig,
  type DevicePassport,
  type CardIconMapping
} from './types/types'
import FiberManualRecordIcon from '@mui/icons-material/FiberManualRecord'

const Item = styled(Paper)(({ theme }) => ({
  ...theme.typography.body2,
  textAlign: 'center',
  color: theme.palette.text.secondary,
  padding: '1.5rem',

  [theme.breakpoints.down('sm')]: {
    padding: '0.875rem'
  },
  [theme.breakpoints.between('lg', 'sm')]: {
    padding: '1.875rem'
  },
  [theme.breakpoints.up('lg')]: {
    padding: '1.5rem'
  }
}))

const SubItem = styled(Paper)(({ theme }) => ({
  backgroundColor: 'var(--background)',
  padding: '0.58rem'
}))

const MyDevice = () => {
  const {
    cardConfig,
    deviceConfig,
    cardIconMapping,
    greetingTitle
  }: {
    cardConfig: CardConfig[]
    deviceConfig: DevicePassport
    cardIconMapping: CardIconMapping
    greetingTitle: string
  } = useMyDevicesConfig()

  return (
    <Box display="flex" flexDirection="column" rowGap="1rem">
      <Typography
        variant="h4"
        lineHeight="160%"
        fontWeight="700"
        color="var(--gray)"
        paddingTop="1.688rem">
        {greetingTitle}
      </Typography>
      {(cardConfig?.length ?? 0) > 0 || false
        ? cardConfig?.map(({ icon, type, text }, index: number) => (
            <Item key={index + type} elevation={1}>
              <Box
                display="flex"
                flexDirection="row"
                gap="1.26rem"
                alignItems="center">
                <Box maxWidth="3.875rem" display="flex" alignItems="center">
                  {cardIconMapping[icon]}
                </Box>
                <Typography
                  variant="h6"
                  lineHeight="normal"
                  fontWeight="400"
                  color="var(--black)"
                  textAlign="left">
                  {text}
                </Typography>
              </Box>
            </Item>
          ))
        : null}

      <Item elevation={1}>
        <Box display="flex" flexDirection="column" rowGap="0.76rem">
          <Typography
            variant="body1"
            textAlign="left"
            color="var(--gray)"
            fontWeight="700"
            lineHeight="160%">
            {deviceConfig.title}
          </Typography>
          <Box display="flex" flexDirection="row">
            <img
              src={deviceConfig.device_detials.device_img_src}
              alt={'device_image'}
              loading="lazy"
            />
            <Box
              display="flex"
              flexDirection="column"
              alignItems="left"
              paddingLeft="2.52rem">
              <Typography
                variant="h5"
                textAlign="left"
                color="var(--black)"
                fontWeight="550"
                lineHeight="160%">
                <>
                  {deviceConfig.device_detials.device_name}
                  <Typography
                    variant="caption"
                    component="span"
                    display="inline"
                    style={{ verticalAlign: 'super' }}
                    color="var(--black)"
                    fontWeight="550"
                    lineHeight="160%">
                    &nbsp;
                    {deviceConfig.device_detials.device_name_supscript}
                  </Typography>
                </>
              </Typography>
              <Box
                display="flex"
                flexDirection="row"
                alignItems="center"
                gap="0.26rem">
                <Typography
                  variant="body1"
                  textAlign="left"
                  color="var(--black)"
                  fontWeight="500"
                  lineHeight="160%">
                  {deviceConfig.device_detials.status_title}
                </Typography>
                <FiberManualRecordIcon
                  sx={{
                    color: '#0ACF97',
                    // marginRight: '1rem',
                    width: '1rem'
                  }}
                />
                <Typography
                  variant="body1"
                  textAlign="left"
                  color="var(--black)"
                  fontWeight="500"
                  lineHeight="160%">
                  {deviceConfig.device_detials.status}
                </Typography>
              </Box>

              <Typography
                variant="body1"
                textAlign="left"
                color="var(--subduedtext)"
                fontWeight="400"
                lineHeight="160%">
                {deviceConfig.device_detials.transmission_schedule_title}
                {deviceConfig.device_detials.transmission_schedule}
              </Typography>
            </Box>
          </Box>
          <SubItem variant="outlined">
            <Box
              display="flex"
              flexDirection="row"
              gap="0.26rem"
              alignItems="flex-start">
              <Box maxWidth="3.875rem" display="flex">
                {deviceConfig.battery_details.battery_icon}
              </Box>
              <Box
                display="flex"
                flexDirection="column"
                alignItems="left"
                paddingLeft="1.69rem">
                <Typography
                  variant="h5"
                  textAlign="left"
                  color="var(--black)"
                  fontWeight="550"
                  lineHeight="160%">
                  {deviceConfig.battery_details.title}
                  {deviceConfig.battery_details.due_date}
                </Typography>

                <Typography variant="body1" textAlign="left" fontWeight="400">
                  {deviceConfig.battery_details.text}
                </Typography>
                <Typography
                  variant="subtitle2"
                  textAlign="left"
                  color="var(--subduedtext)"
                  fontWeight="400"
                  paddingTop="1rem">
                  {deviceConfig.battery_details.note}
                </Typography>
              </Box>
            </Box>
          </SubItem>
          <TableContainer>
            <Table>
              <TableBody>
                {deviceConfig.additional_data.map(row => (
                  <TableRow key={row.title}>
                    <TableCell>
                      <Typography
                        variant="body1"
                        textAlign="left"
                        color="var(--subduedtext)"
                        fontWeight="400">
                        {row.title}
                      </Typography>
                    </TableCell>
                    <TableCell align="right">
                      <Typography
                        variant="body1"
                        textAlign="right"
                        color="var(--black)"
                        fontWeight="400">
                        {row.data}
                      </Typography>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
        </Box>
      </Item>
    </Box>
  )
}

export default MyDevice
