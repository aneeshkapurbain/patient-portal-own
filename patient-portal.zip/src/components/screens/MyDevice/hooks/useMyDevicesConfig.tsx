import BatteryIcon from '../images/BatteryIcon'
import NormalFunc from '../images/NormalFunc'
import NormalTransm from '../images/NormalTransm'
import {
  type DevicePassport,
  type CardConfig,
  type CardIconMapping
} from '../types/types'

const useMyDevicesConfig = (): {
  cardConfig: CardConfig[]
  deviceConfig: DevicePassport
  cardIconMapping: CardIconMapping
  greetingTitle: string
} => {
  const cardConfig: CardConfig[] = [
    {
      type: 'card_config',
      text: 'Your device is functioning normally and stands ready to support you in your daily activities.',
      icon: 'NORMAL_FUNC'
    },
    {
      type: 'card_config',
      text: 'Your home monitor is transmitting and you are under regular monitoring by our care team.',
      icon: 'NORMAL_TRANSM'
    }
  ]

  const deviceConfig: DevicePassport = {
    type: 'device_passort',
    title: 'MY DEVICE PASSPORT',
    device_detials: {
      device_img_src: '/images/device_image.png',
      device_name: 'Abbott Assurity MRI',
      device_name_supscript: 'TM',
      status_title: 'Daily monitoring:',
      status: 'Active',
      transmission_schedule_title: 'Next scheduled transmission:',
      transmission_schedule: 'in 5 months'
    },
    battery_details: {
      title: 'Battery replacement due in ',
      due_date: '2025',
      text: 'Your clinic will notify you when your battery is due for replacement.',
      note: "Note: Battery life is indicative only, determined by the manufacturer's suggested lifespan, and may vary based on usage.",
      battery_icon: <BatteryIcon />
    },
    additional_data: [
      { title: 'Model Number', data: 'PM-2023-X' },
      { title: 'Lead model name', data: 'CardioLink UltraPro' },
      { title: 'Serial number', data: 'X284VFMF03KL2' },
      { title: 'Implant date', data: 'January 15, 2021' }
    ]
  }

  const cardIconMapping: CardIconMapping = {
    NORMAL_FUNC: <NormalFunc />,
    NORMAL_TRANSM: <NormalTransm />
  }

  const greetingTitle: string = 'Hi Mickey Mouse,'

  return { cardConfig, deviceConfig, cardIconMapping, greetingTitle }
}

export default useMyDevicesConfig
