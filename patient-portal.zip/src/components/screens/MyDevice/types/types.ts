import { type ReactNode } from 'react'

export type CardIconMapping = Record<string, ReactNode>

export interface CardConfig {
  type: 'card_config'
  text: string
  icon: 'NORMAL_FUNC' | 'NORMAL_TRANSM'
}

interface additional_data {
  title: string
  data: string
}
export interface DevicePassport {
  type: 'device_passort'
  title: string
  device_detials: {
    device_img_src: string
    device_name: string
    device_name_supscript: string
    status_title: string
    status: string
    transmission_schedule_title: string
    transmission_schedule: string
  }
  battery_details: {
    title: string
    due_date: string
    text: string
    note: string
    battery_icon: ReactNode
  }
  additional_data: additional_data[]
}
