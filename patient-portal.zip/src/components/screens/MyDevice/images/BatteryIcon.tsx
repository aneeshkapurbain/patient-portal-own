const BatteryIcon = () => {
  return (
    <svg
      width="100%"
      height="auto"
      viewBox="0 0 83 84"
      fill="none"
      xmlns="http://www.w3.org/2000/svg">
      <g id="Group 1">
        <g id="Ellipse 2339" filter="url(#filter0_d_117_380)">
          <circle cx="41.5" cy="40.5" r="36.5" fill="white" />
        </g>
        <path
          id="Vector"
          fillRule="evenodd"
          clipRule="evenodd"
          d="M37.2548 17C35.5305 17 34.1394 18.4691 34.1394 20.2723V22.5879H32.9572C30.2155 22.5879 28 24.9244 28 27.7975V58.7908C28 61.6638 30.2155 64 32.9572 64H50.0428C52.7845 64 55 61.6637 55 58.7908V27.7975C55 24.9245 52.7843 22.5879 50.0428 22.5879H48.965V20.2723C48.965 18.4691 47.5742 17 45.8497 17H37.2548ZM46.4178 22.5879H36.6863V20.2723C36.6863 19.9359 36.9443 19.6705 37.2545 19.6705H45.8495C46.1596 19.6705 46.4176 19.9359 46.4176 20.2723L46.4178 22.5879ZM30.5472 27.7975C30.5472 26.3914 31.6301 25.2585 32.9573 25.2585H50.0428C51.37 25.2585 52.4529 26.3914 52.4529 27.7975V58.7908C52.4529 60.197 51.37 61.3297 50.0428 61.3297H32.9573C31.6301 61.3297 30.5472 60.197 30.5472 58.7908V27.7975Z"
          fill="#0F5CA2"
        />
      </g>
      <defs>
        <filter
          id="filter0_d_117_380"
          x="0.04001"
          y="0.69334"
          width="82.92"
          height="82.92"
          filterUnits="userSpaceOnUse"
          colorInterpolationFilters="sRGB">
          <feFlood floodOpacity="0" result="BackgroundImageFix" />
          <feColorMatrix
            in="SourceAlpha"
            type="matrix"
            values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0"
            result="hardAlpha"
          />
          <feOffset dy="1.65333" />
          <feGaussianBlur stdDeviation="2.48" />
          <feColorMatrix
            type="matrix"
            values="0 0 0 0 0.18 0 0 0 0 0.19 0 0 0 0 0.19 0 0 0 0.14 0"
          />
          <feBlend
            mode="normal"
            in2="BackgroundImageFix"
            result="effect1_dropShadow_117_380"
          />
          <feBlend
            mode="normal"
            in="SourceGraphic"
            in2="effect1_dropShadow_117_380"
            result="shape"
          />
        </filter>
      </defs>
    </svg>
  )
}

export default BatteryIcon
