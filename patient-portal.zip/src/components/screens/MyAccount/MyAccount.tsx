import { Box } from '@mui/material'

const MyAccount = (): React.ReactElement => {
  return <Box component="article">{'My Account'}</Box>
}

export default MyAccount
