import { Box } from '@mui/material'

const Faq = () => {
  return <Box component="article">{'Faq'}</Box>
}

export default Faq
