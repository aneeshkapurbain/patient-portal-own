import { Box } from '@mui/material'

const Faq = (): React.ReactElement => {
  return <Box component="article">{'Faq'}</Box>
}

export default Faq
